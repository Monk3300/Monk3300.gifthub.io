# HRGenesis – AI-Powered HR Platform

HRGenesis is a cloud-based platform integrating generative AI into HR workflows such as:
- Predictive performance management
- Org chart design
- Talent assessments
- Automated onboarding

## Key Modules
- Predictive Success Tool
- Analytics Dashboard
- AI-powered 9-box grid
- Admin Dashboard (React + Material UI)